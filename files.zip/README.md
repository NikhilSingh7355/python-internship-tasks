# Python Internship Tasks

**Intern:** Nikhil Singh  
**Application ID:** NJ-KABGLTK  
**Domain:** Python Development Internship  

---

## Task 1 — Student Manager (Flask Web App)

A full-stack web application built with Flask for managing student records with complete CRUD operations.

### Features
- Add, view, edit, delete students
- Search by name or ID
- Summary page with course-wise breakdown
- Clean dark-themed UI

### How to Run Locally
```bash
cd Task1_Student_Manager
pip install -r requirements.txt
python app.py
```
Then open `http://127.0.0.1:5000` in your browser.

### How to Deploy on Render
1. Push this repo to GitHub
2. Go to render.com → New Web Service
3. Connect your GitHub repo
4. Set Root Directory: `Task1_Student_Manager`
5. Build Command: `pip install -r requirements.txt`
6. Start Command: `gunicorn app:app`
7. Click Deploy!

---

## Task 3 — File Automation Script

A Python CLI script that automates real-world file management tasks.

### Features
- Organise files into folders by type (Images, Videos, Code, etc.)
- Batch rename files with a custom prefix
- Sort and list files by size or last modified date
- Find files by extension (recursive search)
- Delete empty folders
- Auto-saves action log to `automation_log.txt`

### How to Run
```bash
cd Task3_Automation_Script
python task3_automation_script.py
```

---

## Project Structure
```
python-internship-tasks/
├── README.md
├── Task1_Student_Manager/
│   ├── app.py
│   ├── requirements.txt
│   ├── Procfile
│   └── templates/
│       ├── base.html
│       ├── index.html
│       ├── add.html
│       ├── edit.html
│       └── summary.html
└── Task3_Automation_Script/
    └── task3_automation_script.py
```
